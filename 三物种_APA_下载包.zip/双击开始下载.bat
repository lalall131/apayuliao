@echo off
cd /d "%~dp0"
py -3 download.py
if errorlevel 1 echo ERROR: Some downloads failed. Run again to retry.
pause
