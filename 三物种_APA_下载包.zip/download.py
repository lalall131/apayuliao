import csv, hashlib, os, sys, time, urllib.request
from pathlib import Path
from urllib.parse import urlparse
ROOT=Path(__file__).resolve().parent

def md5(path):
 h=hashlib.md5()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()

def main():
 with (ROOT/'download_manifest.tsv').open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f,delimiter='\t'))
 if not rows: raise ValueError('Empty manifest')
 errors=[]
 for i,r in enumerate(rows,1):
  dest=ROOT/'FASTQ'/r['species']/r['biosample']/Path(urlparse(r['url']).path).name
  dest.parent.mkdir(parents=True,exist_ok=True)
  if dest.exists() and dest.stat().st_size==int(r['bytes']) and md5(dest).lower()==r['md5'].lower():
   print(f'[{i}/{len(rows)}] verified {dest.name}',flush=True);continue
  tmp=dest.with_name(dest.name+'.part')
  for attempt in range(1,4):
   try:
    print(f'[{i}/{len(rows)}] download {r["url"]} attempt {attempt}',flush=True)
    with urllib.request.urlopen(r['url'],timeout=120) as src, tmp.open('wb') as dst:
     while True:
      block=src.read(1024*1024)
      if not block:break
      dst.write(block)
    if tmp.stat().st_size!=int(r['bytes']) or md5(tmp).lower()!=r['md5'].lower():raise ValueError('size or MD5 mismatch')
    os.replace(tmp,dest);print('verified',dest,flush=True);break
   except Exception as e:
    print('failed:',e,flush=True)
    if attempt==3:errors.append((r['run'],str(e)))
    else:time.sleep(3)
 if errors:
  print('Failed files:',errors,flush=True);sys.exit(1)
 print('All files verified.',flush=True)
if __name__=='__main__':main()
